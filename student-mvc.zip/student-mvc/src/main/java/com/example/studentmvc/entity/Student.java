package com.example.studentmvc.entity;

import javax.persistence.*;
import javax.validation.constraints.*;

/**
 * CONCEPT: Domain / entity class.
 * @Entity + @Table etc. are JPA annotations, mapped by Hibernate to the "students" table.
 * The javax.validation annotations (@NotEmpty, @Email, ...) are enforced by the
 * controller via @Valid, showing Spring MVC's Bean Validation integration.
 */
@Entity
@Table(name = "students")
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotEmpty(message = "{student.name.required}")
    @Size(min = 2, max = 100, message = "{student.name.size}")
    @Column(name = "name", nullable = false, length = 100)
    private String name;

    @NotEmpty(message = "{student.email.required}")
    @Email(message = "{student.email.invalid}")
    @Column(name = "email", nullable = false, unique = true, length = 150)
    private String email;

    @NotNull(message = "{student.age.required}")
    @Min(value = 5, message = "{student.age.min}")
    @Max(value = 100, message = "{student.age.max}")
    @Column(name = "age")
    private Integer age;

    @NotEmpty(message = "{student.course.required}")
    @Column(name = "course", length = 100)
    private String course;

    @Column(name = "photo_path")
    private String photoPath;

    public Student() {
    }

    public Student(String name, String email, Integer age, String course) {
        this.name = name;
        this.email = email;
        this.age = age;
        this.course = course;
    }

    // ----------- getters / setters -----------
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getPhotoPath() {
        return photoPath;
    }

    public void setPhotoPath(String photoPath) {
        this.photoPath = photoPath;
    }
}
