package com.example.studentmvc.config;

import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.filter.HiddenHttpMethodFilter;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

import javax.servlet.Filter;

/**
 * CONCEPT: Java-based web application initializer.
 * This completely replaces web.xml. It tells the servlet container:
 *  - which config class holds "root" (service/dao/datasource) beans      -> RootConfig
 *  - which config class holds "web" (controller/view resolver) beans     -> WebConfig
 *  - what URL pattern the DispatcherServlet (the MVC "front controller") should handle
 */
public class WebAppInitializer extends AbstractAnnotationConfigDispatcherServletInitializer {

    @Override
    protected Class<?>[] getRootConfigClasses() {
        // Service + DAO + DataSource + TransactionManager live in the "root" context
        return new Class<?>[]{RootConfig.class};
    }

    @Override
    protected Class<?>[] getServletConfigClasses() {
        // Controllers + ViewResolver + MVC-specific beans live in the "web" context
        return new Class<?>[]{WebConfig.class};
    }

    @Override
    protected String[] getServletMappings() {
        // DispatcherServlet handles every request ("/") except JSPs (handled by container)
        return new String[]{"/"};
    }

    @Override
    protected Filter[] getServletFilters() {
        // CONCEPT: Servlet Filters registered through Spring
        CharacterEncodingFilter encodingFilter = new CharacterEncodingFilter();
        encodingFilter.setEncoding("UTF-8");
        encodingFilter.setForceEncoding(true);

        // Lets HTML forms send PUT/DELETE via a hidden "_method" field
        HiddenHttpMethodFilter methodFilter = new HiddenHttpMethodFilter();

        return new Filter[]{encodingFilter, methodFilter};
    }
}
