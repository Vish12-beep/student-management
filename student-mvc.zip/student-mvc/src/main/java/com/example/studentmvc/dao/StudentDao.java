package com.example.studentmvc.dao;

import com.example.studentmvc.entity.Student;

import java.util.List;

/**
 * CONCEPT: DAO (Data Access Object) layer - isolates persistence/Hibernate details
 * from the rest of the application.
 */
public interface StudentDao {
    List<Student> findAll();

    Student findById(Long id);

    void save(Student student);

    void update(Student student);

    void deleteById(Long id);
}
