package com.example.studentmvc.exception;

/**
 * CONCEPT: Custom business exception - unchecked so the service layer doesn't
 * force every caller to declare "throws".
 */
public class StudentNotFoundException extends RuntimeException {
    public StudentNotFoundException(String message) {
        super(message);
    }
}
