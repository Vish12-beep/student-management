package com.example.studentmvc.service;

import com.example.studentmvc.dao.StudentDao;
import com.example.studentmvc.entity.Student;
import com.example.studentmvc.exception.StudentNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * CONCEPT: @Service marks this as a business-logic bean.
 * @Transactional (class-level) means every public method runs inside a Hibernate
 * transaction that is committed on success / rolled back on exception.
 */
@Service
@Transactional
public class StudentServiceImpl implements StudentService {

    private final StudentDao studentDao;

    @Autowired
    public StudentServiceImpl(StudentDao studentDao) {
        this.studentDao = studentDao;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Student> findAll() {
        return studentDao.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Student findById(Long id) {
        Student student = studentDao.findById(id);
        if (student == null) {
            // CONCEPT: custom checked business exception, handled globally by @ControllerAdvice
            throw new StudentNotFoundException("No student found with id: " + id);
        }
        return student;
    }

    @Override
    public void save(Student student) {
        if (student.getId() == null) {
            studentDao.save(student);
        } else {
            studentDao.update(student);
        }
    }

    @Override
    public void deleteById(Long id) {
        studentDao.deleteById(id);
    }
}
