package com.example.studentmvc.dao;

import com.example.studentmvc.entity.Student;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * CONCEPT: @Repository - marks this as a persistence-layer bean and enables
 * Spring's exception translation (Hibernate exceptions -> Spring's DataAccessException hierarchy).
 */
@Repository
public class StudentDaoImpl implements StudentDao {

    private final SessionFactory sessionFactory;

    @Autowired
    public StudentDaoImpl(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    private Session currentSession() {
        return sessionFactory.getCurrentSession();
    }

    @Override
    public List<Student> findAll() {
        Query<Student> query = currentSession().createQuery("from Student order by id desc", Student.class);
        return query.getResultList();
    }

    @Override
    public Student findById(Long id) {
        return currentSession().get(Student.class, id);
    }

    @Override
    public void save(Student student) {
        currentSession().save(student);
    }

    @Override
    public void update(Student student) {
        currentSession().update(student);
    }

    @Override
    public void deleteById(Long id) {
        Student student = findById(id);
        if (student != null) {
            currentSession().delete(student);
        }
    }
}
