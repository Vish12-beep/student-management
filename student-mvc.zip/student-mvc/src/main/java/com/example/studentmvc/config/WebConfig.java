package com.example.studentmvc.config;

import com.example.studentmvc.interceptor.LoggingInterceptor;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.config.annotation.*;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.web.servlet.view.JstlView;

import java.util.Locale;

/**
 * CONCEPT: "Web" application context. Holds Controllers, ViewResolver, Interceptors,
 * static-resource mapping, file-upload (multipart) config and internationalization (i18n).
 *
 * @EnableWebMvc turns on standard Spring MVC features (this is the annotation-config
 * equivalent of <mvc:annotation-driven/> in XML).
 */
@Configuration
@EnableWebMvc
@ComponentScan(basePackages = "com.example.studentmvc.controller")
public class WebConfig implements WebMvcConfigurer {

    // ---------- VIEW RESOLVER: maps logical view names -> /WEB-INF/views/xxx.jsp ----------
    @Bean
    public InternalResourceViewResolver viewResolver() {
        InternalResourceViewResolver resolver = new InternalResourceViewResolver();
        resolver.setViewClass(JstlView.class);
        resolver.setPrefix("/WEB-INF/views/");
        resolver.setSuffix(".jsp");
        return resolver;
    }

    // ---------- STATIC RESOURCES: css/js/images served without going through a controller ----------
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/resources/**").addResourceLocations("/resources/");
    }

    // ---------- INTERCEPTORS: cross-cutting logic that runs before/after every controller ----------
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new LoggingInterceptor());
        registry.addInterceptor(localeChangeInterceptor());
    }

    // ---------- I18N: change language via ?lang=fr on any URL ----------
    @Bean
    public LocaleChangeInterceptor localeChangeInterceptor() {
        LocaleChangeInterceptor interceptor = new LocaleChangeInterceptor();
        interceptor.setParamName("lang");
        return interceptor;
    }

    @Bean
    public LocaleResolver localeResolver() {
        SessionLocaleResolver resolver = new SessionLocaleResolver();
        resolver.setDefaultLocale(Locale.ENGLISH);
        return resolver;
    }

    @Bean
    public MessageSource messageSource() {
        ReloadableResourceBundleMessageSource source = new ReloadableResourceBundleMessageSource();
        source.setBasename("classpath:messages");
        source.setDefaultEncoding("UTF-8");
        source.setUseCodeAsDefaultMessage(true);
        return source;
    }

    // ---------- FILE UPLOAD: required so @RequestParam MultipartFile works ----------
    @Bean
    public CommonsMultipartResolver multipartResolver() {
        CommonsMultipartResolver resolver = new CommonsMultipartResolver();
        resolver.setMaxUploadSize(5 * 1024 * 1024); // 5 MB
        resolver.setDefaultEncoding("UTF-8");
        return resolver;
    }
}
