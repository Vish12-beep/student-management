package com.example.studentmvc.controller;

import com.example.studentmvc.entity.Student;
import com.example.studentmvc.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;
import java.io.File;
import java.io.IOException;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;

/**
 * CONCEPT: @Controller - a "classic" Spring MVC controller that returns view names
 * (JSP pages), as opposed to @RestController which returns data directly.
 *
 * Demonstrates: @RequestMapping/@GetMapping/@PostMapping, @PathVariable, @ModelAttribute,
 * @Valid + BindingResult (server-side validation), RedirectAttributes (flash messages,
 * Post/Redirect/Get pattern), and MultipartFile (file upload).
 */
@Controller
@RequestMapping("/students")
public class StudentController {

    private final StudentService studentService;

    @Autowired
    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    // ---------------- LIST ----------------
    @GetMapping({"", "/"})
    public String list(Model model) {
        model.addAttribute("students", studentService.findAll());
        return "student/list"; // -> /WEB-INF/views/student/list.jsp
    }

    // ---------------- SHOW ADD FORM ----------------
    @GetMapping("/new")
    public String showAddForm(Model model) {
        model.addAttribute("student", new Student());
        return "student/form";
    }

    // ---------------- SHOW EDIT FORM ----------------
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable("id") Long id, Model model) {
        model.addAttribute("student", studentService.findById(id));
        return "student/form";
    }

    // ---------------- SAVE (CREATE or UPDATE) ----------------
    @PostMapping("/save")
    public String save(@Valid @ModelAttribute("student") Student student,
                        BindingResult result,
                        @RequestParam(value = "photo", required = false) MultipartFile photo,
                        HttpServletRequest request,
                        RedirectAttributes redirectAttributes) {

        // CONCEPT: server-side bean validation - if invalid, redisplay the same form with errors
        if (result.hasErrors()) {
            return "student/form";
        }

        // CONCEPT: file upload handling
        if (photo != null && !photo.isEmpty()) {
            try {
                String uploadDir = request.getServletContext().getRealPath("/resources/uploads/");
                File dir = new File(uploadDir);
                if (!dir.exists()) {
                    dir.mkdirs();
                }
                String fileName = UUID.randomUUID() + "_" + photo.getOriginalFilename();
                photo.transferTo(new File(dir, fileName));
                student.setPhotoPath("resources/uploads/" + fileName);
            } catch (IOException e) {
                throw new RuntimeException("Failed to store uploaded file", e);
            }
        }

        boolean isUpdate = student.getId() != null;
        studentService.save(student);

        // CONCEPT: RedirectAttributes -> flash message that survives exactly one redirect (Post/Redirect/Get)
        redirectAttributes.addFlashAttribute("successMessage",
                isUpdate ? "Student updated successfully!" : "Student added successfully!");

        // CONCEPT: redirect (not forward) after POST, to avoid duplicate form resubmission on refresh
        return "redirect:/students";
    }

    // ---------------- DELETE ----------------
    @GetMapping("/delete/{id}")
    public String delete(@PathVariable("id") Long id, RedirectAttributes redirectAttributes) {
        studentService.deleteById(id);
        redirectAttributes.addFlashAttribute("successMessage", "Student deleted successfully!");
        return "redirect:/students";
    }

    // ---------------- VIEW SINGLE STUDENT ----------------
    @GetMapping("/view/{id}")
    public String view(@PathVariable("id") Long id, Model model) {
        model.addAttribute("student", studentService.findById(id));
        return "student/view";
    }
}
