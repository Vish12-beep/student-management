package com.example.studentmvc.interceptor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * CONCEPT: HandlerInterceptor - cross-cutting logic (logging, auth checks, timing)
 * that runs before the controller (preHandle), after the controller but before the
 * view renders (postHandle), and after the view has rendered (afterCompletion).
 */
public class LoggingInterceptor implements HandlerInterceptor {

    private static final Logger logger = LoggerFactory.getLogger(LoggingInterceptor.class);
    private static final ThreadLocal<Long> startTime = new ThreadLocal<>();

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        startTime.set(System.currentTimeMillis());
        logger.info(">>> Incoming request: {} {}", request.getMethod(), request.getRequestURI());
        return true; // return false to stop the request from reaching the controller
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) {
        logger.info(">>> Controller finished, about to render view: {}",
                modelAndView != null ? modelAndView.getViewName() : "none");
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
        long timeTaken = System.currentTimeMillis() - startTime.get();
        logger.info(">>> Request to {} completed in {} ms", request.getRequestURI(), timeTaken);
        startTime.remove();
    }
}
