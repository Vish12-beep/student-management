package com.example.studentmvc.service;

import com.example.studentmvc.entity.Student;

import java.util.List;

/**
 * CONCEPT: Service layer - holds business logic and transaction boundaries,
 * sits between the Controller and the DAO.
 */
public interface StudentService {
    List<Student> findAll();

    Student findById(Long id);

    void save(Student student);

    void deleteById(Long id);
}
