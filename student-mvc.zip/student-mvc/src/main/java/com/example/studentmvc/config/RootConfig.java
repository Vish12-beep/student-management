package com.example.studentmvc.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.hibernate.SessionFactory;
import org.springframework.context.annotation.*;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;
import java.util.Properties;

/**
 * CONCEPT: "Root" application context.
 * Holds everything that is NOT web-specific: DataSource, Hibernate SessionFactory,
 * TransactionManager, and component-scans the service/dao packages.
 *
 * @EnableTransactionManagement activates Spring's declarative @Transactional support.
 */
@Configuration
@ComponentScan(basePackages = {"com.example.studentmvc.service", "com.example.studentmvc.dao"})
@EnableTransactionManagement
public class RootConfig {

    // ---- Update these 4 values to match your local MySQL setup ----
    private static final String DB_URL =
            "jdbc:mysql://localhost:3306/student_db?useSSL=false&serverTimezone=UTC&createDatabaseIfNotExist=true";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "root";
    private static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";

    @Bean
    public DataSource dataSource() {
        // CONCEPT: Connection pooling with HikariCP instead of creating a new connection per request
        HikariConfig config = new HikariConfig();
        config.setDriverClassName(DB_DRIVER);
        config.setJdbcUrl(DB_URL);
        config.setUsername(DB_USER);
        config.setPassword(DB_PASSWORD);
        config.setMaximumPoolSize(10);
        return new HikariDataSource(config);
    }

    @Bean
    public LocalSessionFactoryBean sessionFactory() {
        // CONCEPT: Hibernate SessionFactory managed by Spring
        LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
        sessionFactory.setDataSource(dataSource());
        sessionFactory.setPackagesToScan("com.example.studentmvc.entity");
        sessionFactory.setHibernateProperties(hibernateProperties());
        return sessionFactory;
    }

    private Properties hibernateProperties() {
        Properties props = new Properties();
        props.put("hibernate.dialect", "org.hibernate.dialect.MySQL8Dialect");
        // auto-create/update the "students" table from the entity on startup
        props.put("hibernate.hbm2ddl.auto", "update");
        props.put("hibernate.show_sql", "true");
        props.put("hibernate.format_sql", "true");
        return props;
    }

    @Bean
    public HibernateTransactionManager transactionManager(SessionFactory sessionFactory) {
        // CONCEPT: Declarative transaction management (@Transactional in the service layer)
        return new HibernateTransactionManager(sessionFactory);
    }
}
