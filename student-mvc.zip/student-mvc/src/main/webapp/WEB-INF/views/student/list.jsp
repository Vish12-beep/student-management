<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags" %>
<!DOCTYPE html>
<html>
<head>
    <title><spring:message code="app.title"/></title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/resources/css/style.css">
</head>
<body>
<div class="container">
    <div class="top-bar">
        <h1><spring:message code="app.title"/></h1>
        <!-- CONCEPT: i18n language switch, handled by LocaleChangeInterceptor via ?lang= -->
        <div class="lang-switch">
            <a href="?lang=en">EN</a> | <a href="?lang=fr">FR</a>
        </div>
    </div>

    <!-- CONCEPT: flash attribute set by RedirectAttributes, shown once after redirect -->
    <c:if test="${not empty successMessage}">
        <div class="alert-success">${successMessage}</div>
    </c:if>

    <p><a class="btn btn-add" href="${pageContext.request.contextPath}/students/new">
        <spring:message code="button.add"/></a></p>

    <table>
        <thead>
        <tr>
            <th>ID</th>
            <th><spring:message code="label.name"/></th>
            <th><spring:message code="label.email"/></th>
            <th><spring:message code="label.age"/></th>
            <th><spring:message code="label.course"/></th>
            <th><spring:message code="label.actions"/></th>
        </tr>
        </thead>
        <tbody>
        <c:forEach var="s" items="${students}">
            <tr>
                <td>${s.id}</td>
                <td>${s.name}</td>
                <td>${s.email}</td>
                <td>${s.age}</td>
                <td>${s.course}</td>
                <td>
                    <a class="btn btn-view" href="${pageContext.request.contextPath}/students/view/${s.id}">
                        <spring:message code="button.view"/></a>
                    <a class="btn btn-edit" href="${pageContext.request.contextPath}/students/edit/${s.id}">
                        <spring:message code="button.edit"/></a>
                    <a class="btn btn-delete" href="${pageContext.request.contextPath}/students/delete/${s.id}"
                       onclick="return confirm('Delete this student?');">
                        <spring:message code="button.delete"/></a>
                </td>
            </tr>
        </c:forEach>
        <c:if test="${empty students}">
            <tr><td colspan="6">No students found. Add one above.</td></tr>
        </c:if>
        </tbody>
    </table>
</div>
</body>
</html>
