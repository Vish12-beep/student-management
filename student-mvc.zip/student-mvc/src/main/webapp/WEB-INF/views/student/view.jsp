<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags" %>
<!DOCTYPE html>
<html>
<head>
    <title><spring:message code="app.title"/></title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/resources/css/style.css">
</head>
<body>
<div class="container">
    <h1>Student Details</h1>
    <c:if test="${not empty student.photoPath}">
        <img src="${pageContext.request.contextPath}/${student.photoPath}" width="120" alt="photo"/>
    </c:if>
    <table>
        <tr><th>ID</th><td>${student.id}</td></tr>
        <tr><th><spring:message code="label.name"/></th><td>${student.name}</td></tr>
        <tr><th><spring:message code="label.email"/></th><td>${student.email}</td></tr>
        <tr><th><spring:message code="label.age"/></th><td>${student.age}</td></tr>
        <tr><th><spring:message code="label.course"/></th><td>${student.course}</td></tr>
    </table>
    <p><a class="btn btn-view" href="${pageContext.request.contextPath}/students">Back to list</a></p>
</div>
</body>
</html>
