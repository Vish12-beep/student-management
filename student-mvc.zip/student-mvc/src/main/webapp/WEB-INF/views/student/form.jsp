<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="spring" uri="http://www.springframework.org/tags" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
    <title><spring:message code="app.title"/></title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/resources/css/style.css">
</head>
<body>
<div class="container">
    <h1>${student.id != null ? 'Edit Student' : 'Add Student'}</h1>

    <!-- CONCEPT: form:form binds directly to the "student" model attribute.
         enctype=multipart/form-data is required for the file upload field. -->
    <form:form modelAttribute="student" action="${pageContext.request.contextPath}/students/save"
               method="post" enctype="multipart/form-data">

        <form:hidden path="id"/>

        <div class="form-group">
            <label><spring:message code="label.name"/></label>
            <form:input path="name" cssClass="form-control"/>
            <!-- CONCEPT: form:errors automatically shows the @Valid violation message -->
            <form:errors path="name" cssClass="error"/>
        </div>

        <div class="form-group">
            <label><spring:message code="label.email"/></label>
            <form:input path="email" type="email"/>
            <form:errors path="email" cssClass="error"/>
        </div>

        <div class="form-group">
            <label><spring:message code="label.age"/></label>
            <form:input path="age" type="number"/>
            <form:errors path="age" cssClass="error"/>
        </div>

        <div class="form-group">
            <label><spring:message code="label.course"/></label>
            <form:select path="course">
                <form:option value="" label="-- Select course --"/>
                <form:option value="Computer Science"/>
                <form:option value="Mechanical Engineering"/>
                <form:option value="Electronics"/>
                <form:option value="Business Administration"/>
            </form:select>
            <form:errors path="course" cssClass="error"/>
        </div>

        <div class="form-group">
            <label><spring:message code="label.photo"/></label>
            <input type="file" name="photo"/>
            <c:if test="${not empty student.photoPath}">
                <p><small>Current: ${student.photoPath}</small></p>
            </c:if>
        </div>

        <button type="submit" class="btn-save"><spring:message code="button.save"/></button>
        <a href="${pageContext.request.contextPath}/students">Cancel</a>
    </form:form>
</div>
</body>
</html>
