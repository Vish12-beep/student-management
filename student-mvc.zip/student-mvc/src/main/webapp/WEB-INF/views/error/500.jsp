<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head><title>Server Error</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/resources/css/style.css"></head>
<body>
<div class="container">
    <h1>500 - Something went wrong</h1>
    <p>${errorMessage}</p>
    <a href="${pageContext.request.contextPath}/students">Back to student list</a>
</div>
</body>
</html>
