<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head><title>Not Found</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/resources/css/style.css"></head>
<body>
<div class="container">
    <h1>404 - Not Found</h1>
    <p>${errorMessage}</p>
    <a href="${pageContext.request.contextPath}/students">Back to student list</a>
</div>
</body>
</html>
